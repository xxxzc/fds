<template>
  <section class="hero is-primary">
    <div class="hero-body">
      <div class="container">
        <h1 class="title">
          The Foundation of Data Science
        </h1>
        <h2 class="subtitle">
          数据科学基础 课程主页
        </h2>
      </div>
    </div>
  </section>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'home'
}
</script>
